const express = require('express')
const app = express();
const port = process.env.PORT || 3000;
const cors = require('cors');
app.use(cors({
    origin: '*'
}));

// App Routers
const appLoginRouter = require('./routes/app/login');
app.use(express.json());
app.use('/app/login', appLoginRouter)

const appCategoriesRouter = require('./routes/app/categories');
app.use(express.json());
app.use('/app/categories', appCategoriesRouter)

const appChampionshipsRouter = require('./routes/app/championships');
app.use(express.json());
app.use('/app/championships', appChampionshipsRouter)

// Admin Routers
const adminLoginRouter = require('./routes/admin/login');
app.use(express.json());
app.use('/admin/login', adminLoginRouter)

app.get('/', (req,res) => {
    res.send('<h1>Node.js crud API</h1>')
})

app.get('/health', (req,res) => {
    res.send("API Health");
})

app.listen(port, () => {
    console.log('Listening port: ' + port);
})