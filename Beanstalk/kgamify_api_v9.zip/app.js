const express = require('express')
const app = express();
const port = process.env.PORT || 3000;

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    next();
});

// App Routers
const appLoginRouter = require('./routes/app/login');
app.use(express.json());
app.use('/app/login', appLoginRouter)

// Admin Routers
const adminLoginRouter = require('./routes/admin/login');
app.use(express.json());
app.use('/admin/login', adminLoginRouter)

app.get('/', (req,res) => {
    res.send('<h1>Node.js crud API</h1>')
})

app.get('/health', (req,res) => {
    res.send("API Health");
})

app.listen(port, () => {
    console.log('Listening port: ' + port);
})